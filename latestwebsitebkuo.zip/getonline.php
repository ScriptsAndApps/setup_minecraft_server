<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


     $host = $_GET['ip'];
     $port =  $_GET['port'];

	Error_Reporting( E_ALL | E_STRICT );
	Ini_Set( 'display_errors', true );

    //echo $host . ":" . $port;


class MinecraftPing
{

	private $Socket;
	private $ServerAddress;
	private $ServerPort;
	private $Timeout;

	public function __construct( $Address, $Port = 25565, $Timeout = 2, $ResolveSRV = true )
	{
		$this->ServerAddress = $Address;
		$this->ServerPort = (int)$Port;
		$this->Timeout = (int)$Timeout;

		if( $ResolveSRV )
		{
			$this->ResolveSRV();
		}

		$this->Connect( );
	}

	public function __destruct( )
	{
		$this->Close( );
	}

	public function Close( )
	{
		if( $this->Socket !== null )
		{
			\fclose( $this->Socket );

			$this->Socket = null;
		}
	}

	public function Connect( )
	{
		$this->Socket = @\fsockopen( $this->ServerAddress, $this->ServerPort, $errno, $errstr, (float)$this->Timeout );

		if( !$this->Socket )
		{
			$this->Socket = null;

			throw new MinecraftPingException( "Failed to connect or create a socket: $errno ($errstr)" );
		}

		// Set Read/Write timeout
		\stream_set_timeout( $this->Socket, $this->Timeout );
	}

	public function Query( )
	{
		$TimeStart = \microtime( true ); // for read timeout purposes

		// See http://wiki.vg/Protocol (Status Ping)
		$Data = "\x00"; // packet ID = 0 (varint)

		$Data .= "\x04"; // Protocol version (varint)
		$Data .= \pack( 'c', \strlen( $this->ServerAddress ) ) . $this->ServerAddress; // Server (varint len + UTF-8 addr)
		$Data .= \pack( 'n', $this->ServerPort ); // Server port (unsigned short)
		$Data .= "\x01"; // Next state: status (varint)

		$Data = \pack( 'c', \strlen( $Data ) ) . $Data; // prepend length of packet ID + data

		fwrite( $this->Socket, $Data . "\x01\x00" ); // handshake followed by status ping

		$Length = $this->ReadVarInt( ); // full packet length

		if( $Length < 10 )
		{
			return FALSE;
		}

		$this->ReadVarInt( ); // packet type, in server ping it's 0

		$Length = $this->ReadVarInt( ); // string length

		$Data = "";
		while( \strlen( $Data ) < $Length )
		{
			if( \microtime( true ) - $TimeStart > $this->Timeout )
			{
				throw new MinecraftPingException( 'Server read timed out' );
			}

			$Remainder = $Length - \strlen( $Data );
			$block = \fread( $this->Socket, $Remainder ); // and finally the json string
			// abort if there is no progress
			if( !$block )
			{
				throw new MinecraftPingException( 'Server returned too few data' );
			}

			$Data .= $block;
		}
		
	

		$Data = \json_decode( $Data, true );

		if( \json_last_error( ) !== JSON_ERROR_NONE )
		{
			throw new MinecraftPingException( 'JSON parsing failed: ' . \json_last_error_msg( ) );
		}

		return $Data;
	}

	public function QueryOldPre17( )
	{
		\fwrite( $this->Socket, "\xFE\x01" );
		$Data = \fread( $this->Socket, 512 );
		$Len = \strlen( $Data );

		if( $Len < 4 || $Data[ 0 ] !== "\xFF" )
		{
			return FALSE;
		}

		$Data = \substr( $Data, 3 ); // Strip packet header (kick message packet and short length)
		$Data = \iconv( 'UTF-16BE', 'UTF-8', $Data );

		// Are we dealing with Minecraft 1.4+ server?
		if( $Data[ 1 ] === "\xA7" && $Data[ 2 ] === "\x31" )
		{
			$Data = \explode( "\x00", $Data );

			return Array(
				'HostName'   => $Data[ 3 ],
				'Players'    => (int)$Data[ 4 ],
				'MaxPlayers' => (int)$Data[ 5 ],
				'Protocol'   => (int)$Data[ 1 ],
				'Version'    => $Data[ 2 ]
			);
		}

		$Data = \explode( "\xA7", $Data );

		return Array(
			'HostName'   => \substr( $Data[ 0 ], 0, -1 ),
			'Players'    => isset( $Data[ 1 ] ) ? (int)$Data[ 1 ] : 0,
			'MaxPlayers' => isset( $Data[ 2 ] ) ? (int)$Data[ 2 ] : 0,
			'Protocol'   => 0,
			'Version'    => '1.3'
		);
	}

	private function ReadVarInt( )
	{
		$i = 0;
		$j = 0;

		while( true )
		{
			$k = @\fgetc( $this->Socket );

			if( $k === FALSE )
			{
				return 0;
			}

			$k = \ord( $k );

			$i |= ( $k & 0x7F ) << $j++ * 7;

			if( $j > 5 )
			{
				throw new MinecraftPingException( 'VarInt too big' );
			}

			if( ( $k & 0x80 ) != 128 )
			{
				break;
			}
		}

		return $i;
	}

	private function ResolveSRV()
	{
		if( \ip2long( $this->ServerAddress ) !== false )
		{
			return;
		}

		$Record = @\dns_get_record( '_minecraft._tcp.' . $this->ServerAddress, DNS_SRV );

		if( empty( $Record ) )
		{
			return;
		}

		if( isset( $Record[ 0 ][ 'target' ] ) )
		{
			$this->ServerAddress = $Record[ 0 ][ 'target' ];
		}

		if( isset( $Record[ 0 ][ 'port' ] ) )
		{
			$this->ServerPort = $Record[ 0 ][ 'port' ];
		}
	}
}


class MinecraftPingException extends \Exception
{
	// Exception thrown by MinecraftPing class
}






	// Edit this ->
	define( 'MQ_SERVER_ADDR',  $host );
	define( 'MQ_SERVER_PORT',  $port  );
	define( 'MQ_TIMEOUT', 1 );
	// Edit this <-

	// Display everything in browser, because some people can't look in logs for errors
	Error_Reporting( E_ALL | E_STRICT );
	Ini_Set( 'display_errors', true );


	$Timer = MicroTime( true );

	$Info = false;
	$Query = null;

	try
	{
		$Query = new MinecraftPing( MQ_SERVER_ADDR, MQ_SERVER_PORT, MQ_TIMEOUT );

		$Info = $Query->Query( );

		if( $Info === false )
		{
			$Query->Close( );
			$Query->Connect( );
			$Info = $Query->QueryOldPre17( );
		}
	}
	catch( MinecraftPingException $e )
	{
		$Exception = $e;
	}

	if( $Query !== null )
	{
		$Query->Close( );
	}
	$Timer = Number_Format( MicroTime( true ) - $Timer, 4, '.', '' );
	
	
if( isset( $Exception ) ){

		echo "Offline";
		
  		 //echo htmlspecialchars( $Exception->getMessage( ) ); 
		 //echo nl2br( $e->getTraceAsString(), false );

}else{		 
    

			 
            if( isset($_GET['full'] )){
        
        			 if( $Info !== false ){ 
        		     
        		    // echo ",\"ping\":\"".$Timer."\"}";
        		      
$playersmax = 0;     			     
$players = 0;
$version = "";
$versionProt = "";
$description = null;
$modinfo = null;
$favicon = "";
//$host
//$port



        			     foreach( $Info as $InfoKey => $InfoValue ){
                    			     
                    			     //echo htmlspecialchars( $InfoKey ); 
                    			     
                    				if( $InfoKey === 'players' )
                    				{
                    				    $playersmax =    $InfoValue["max"];
                    				    $players = $InfoValue["online"];
                    				}else  
                    				if( $InfoKey === 'favicon' )
                    				{
                    				$favicon = '<img width="64" height="64" src="' . Str_Replace( "\n", "", $InfoValue ) . '">';
                    				}else  
                    				if( $InfoKey === 'version' )
                    				{
                    				    $version = $InfoValue["name"];
                    				    $versionProt = $InfoValue["protocol"];
                    				}else  
                    				if( $InfoKey === 'description' )
                    				{
                    				    $description = $InfoValue;
                    				
                    				}else if( $InfoKey === 'modinfo' )
                    				{
                    				    $modinfo = $InfoValue;
                    				}else if( Is_Array( $InfoValue ) )
                    				{
                    					echo "<pre>";
                    				//	print_r( $InfoValue );
                    					echo "</pre>";
                    				}
                    				else
                    				{
                    					//echo htmlspecialchars( $InfoValue );
                    				}
                    	
        			     }

        			     
        			      	
        			  //   print_r($favicon);
        		
$okk = 0;
   foreach( $description as $InfoKey => $InfoValue ){
           
        if( Is_Array($InfoValue) ){
                  foreach(  $InfoValue as $InfoKeys => $InfoValues   ){
                      $okk =1;
                      break;
                } 
           }
           
   }

if($okk == 0){
         $status = json_decode(file_get_contents('https://api.mcsrvstat.us/2/'.$host.":".$port));
        $players =$status->players->online;
        $playersmax=$status->players->max;
}
                    		
        			      echo "<b >Total players online: <a style=\"color:#229922\">".$players."</a>/<a style=\"color:#226622\">".$playersmax."</a></b></div>";	

                                //  echo "<pre>";print_r( $Info);echo "</pre>";   //all info debug                  			
                              //    print_r($Timer);  // ping
                              //	print_r($version);
                              //	print_r($versionProt);
        			          //	print_r($modinfo);
        			     
        			 }else{
        			      //echo $Timer;
        			     //	echo "no info"; 
        			 } 
            }
}