<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if ($_SERVER['HTTP_HOST']!="www.gith.me") {
    $_SERVER['HTTP_HOST']  = "www.gith.me";
    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $location);
    exit;
}

//echo file_get_contents("http://193.110.160.210:27171/".$_GET['path'])
?><!DOCTYPE html>
<html lang="en"><head>
    
    
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
  
    <link rel="preload" href="https://fonts.gstatic.com/s/raleway/v22/1Ptxg8zYS_SKggPN4iEgvnHyvveLxVvaorCIPrE.woff2" as="font" crossorigin="anonymous">
    <link rel="preload" href="https://fonts.gstatic.com/s/raleway/v22/1Ptxg8zYS_SKggPN4iEgvnHyvveLxVsEpbCIPrE.woff2" as="font" crossorigin="anonymous">

    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no">

	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	<link rel="manifest" href="site.webmanifest">

    <link rel=”mask-icon” href="mask.svg" color="#cccccc">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    
    <meta name="keywords" content="minecraft, map, dynamic, liveatlas, survival" />
	<meta name="description" content="Minecraft Dynamic Map index" />
    
    <!--link rel="icon" href="favicon.svg"-->
    <link rel="icon" href="https://getbootstrap.com/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Creepers Minecraft Survival Server</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/album/">




    <!-- Bootstrap core CSS -->
    <link href="/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/album.css" rel="stylesheet">
    
    
        <script src="/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="jquery-slim.min.js"><\/script>')
        </script> 
        
        
        
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css"
      id="theme-styles"
    />

        
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js?t=<?php echo time(); ?>"></script>
     
     

     
     
     
     
     
  </head>

  <body>

    <header>
      <div class="collapse bg-dark" id="navbarHeader">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 col-md-7 py-4">
              <h4 class="text-white">Creepers vanilla survival server</h4>
              <h4 class="text-white" onclick="successip('gith.me')"  >Server ip: <a style="color:#00DD00" >gith.me</a></h4>
              <p class="text-muted">Survival, skyblock, chatlobby</p>
            </div>
            <div class="col-sm-4 offset-md-1 py-4">
              <h4 class="text-white">Dynmap Atlas servers maps</h4>
              <ul class="list-unstyled">
                <li><a href="https://map.gith.me" target=”_blank”  class="text-white">survival</a></li>
                <li><a href="https://sky.gith.me" target=”_blank”  class="text-white">skyblock</a></li>
                <li><a href="https://lobby.gith.me" target=”_blank”  class="text-white">lobby</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="navbar navbar-dark bg-dark box-shadow">
        <div class="container d-flex justify-content-between">
          <a href="#" class="navbar-brand d-flex align-items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><path d="M 9.8 14.6 L 17 6.2 L 20.6 5 L 19.4 8.6 L 11 15.8 C 12.2 17 12.2 18.2 13.4 17 C 13.4 18.2 14.6 19.4 13.4 19.4 A 1.704 1.704 90 0 1 12.2 20.6 A 6 6 90 0 0 9.8 17 Q 9.2 16.88 9.2 17.6 T 7.4 19.16 T 6.44 18.2 T 8 16.4 T 8.6 15.8 A 6 6 90 0 0 5 13.4 A 1.704 1.704 90 0 1 6.2 12.2 C 6.2 11 7.4 12.2 8.6 12.2 C 7.4 13.4 8.6 13.4 9.8 14.6 M 17 6.2 L 17 8.6 L 19.4 8.6 L 17.24 8.36 L 17 6.2"></path>
            <circle cx="2" cy="2" r="1"></circle>
            <circle cx="2" cy="7" r="1"></circle>
            <circle cx="6.3" cy="4.5" r="1"></circle></svg>
            <strong>Creepers Survival Server</strong>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
      </div>
    </header>

    <main role="main">





      <section style="padding:40px" class="jumbotron text-center">
        <div class="container">
          <h1 onclick="successip('gith.me')"  class="jumbotron-heading">Server Hub ip: <b> <a style="color:#008800" >gith.me</a></b></h1>

          <p class="lead text-muted">Rules: Dont grief, respect others builds, have fun! </p>
          <p>
         <!-- button onclick="successip('gith.me')"  class="btn btn-sm btn-outline-secondary" data-tooltip-id="1" title="Copied gith.me to clipboard">Copy ip to clipboard</button -->
           </p>
           <h4>Like to connect to a sigle game mode instead of the hub?</h4>
           <h4>Use these direct server domains instead!</h4>
           <p>
                <h4 onclick="successip('survival.gith.me')" >Survival SMP <a  style="color:#008800">survival.gith.me</a></h4>
               <h4 onclick="successip('skyblock.gith.me')" >Skyblock <a  style="color:#5588FF">skyblock.gith.me</a></h4>
               <h4 onclick="successip('hub.gith.me')" >Server Hub <a  style="color:#FF9999">hub.gith.me</a></h4>
          </p>
          
         
             <center>
                 <a  id="server_status_players" name="gith.me" value="25565" class="status"></a>
              </center>
       
          
          
        </div>   
      </section>

<script>

function successip(ip){

  navigator.clipboard.writeText(ip);
    

  Swal.fire({
  position: 'top',
  icon: 'success',
  title: 'Copied serverip to clipboard ' + ip,
  showConfirmButton: false,
  timer: 1000
});

}

</script>



      <div class="album py-5 bg-light">
        <div class="container">


          <div class="row">
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                <iframe width="100%" height="300px" src="https://map.gith.me/#world;flat;0,64,0;8"  id="survival" name="survival" runat="server" ></iframe>
          
                
                <div class="card-body">
                  <p class="card-text">Survival, see who is where, find structures, explore</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <a target=”_blank”  href="https://map.gith.me/" type="button" class="btn btn-sm btn-outline-secondary">View</a>
                    </div>
                    <small class="text-muted">Survival</small>
                  </div>
                </div>
              </div>
            </div>
			
			
            <div class="col-lg-4" >
              <div class="card lg-4 box-shadow">
                  <iframe width="100%" height="300px" src="https://sky.gith.me/#world;flat;9,64,7;11">
  </iframe>
                <div class="card-body">
                  <p class="card-text">Skyblock dynmap, see who is where</p><br>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                       <a target=”_blank”  href="https://sky.gith.me/" type="button" class="btn btn-sm btn-outline-secondary">View</a>
                    </div>
                    <small class="text-muted">SkyBlock</small>
                  </div>
                </div>
              </div>
            </div>
			
			
            <div class="col-lg-4">
              <div class="card lg-4 box-shadow">
                  <iframe width="100%" height="300px" src="https://lobby.gith.me/#world;flat;6,64,7;5">
  </iframe>
                <div class="card-body">
                  <p class="card-text">Sever hub dynmap, see whos online</p><br>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                       <a target=”_blank”  href="https://lobby.gith.me/" type="button" class="btn btn-sm btn-outline-secondary">View</a>
                    </div>
                    <small class="text-muted">Hub</small>
                  </div>
                </div>
              </div>
            </div>
            
            

          </div>
           <br />
          
          
          <!-- STATUS -->


 


          <div class="row">
              
    

   
              
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                  <h5>Survival server status</h5>
                <p id="server_status" name="direct.gith.me" value="27200" class="status"></p>
              </div>
 
            </div>

   
              
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                  <h5>Skyblock server status</h5>
                <p id="server_status" name="direct.gith.me" value="27201" class="status"></p>
              </div>
 
            </div>
            
            
            
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                  <h5>Lobby world server status</h5>
                <p id="server_status" name="direct.gith.me" value="27211" class="status"></p>
              </div>
 
            </div>
            
   
          </div>
          <br />

          
          
          
          
          
          
          
          
          
          
          
          
          
          


          <div class="row">
              
    

   
              
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                  <h5>Survival Direct proxy server</h5>
                <p id="server_status" name="survival.gith.me" value="25565" class="status"></p>
              </div>
 
            </div>

   
              
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                   <h5>Skyblock Direct proxy server</h5>
                <p id="server_status" name="skyblock.gith.me" value="25565" class="status"></p>
              </div>
 
            </div>
            
            
            
            <div class="col col-lg-4">
              <div class="card-12 lg-4 box-shadow">
                   <h5>gith.me MAIN hub proxy server</h5>
                <p id="server_status" name="gith.me" value="27207" class="status"></p>
              </div>
 
            </div>
            
   
          </div>
          <br />
          
 
          
          
          
          
          
            <script>
                function status(){ 
                    $('a[id^="server_status_players"]').each(function () {
                        var el = $(this);
                        var url = "getonline.php?ip=" +  el.attr('name') + "&port="+ el.attr('value') +"&full";
                        $.get( url, function( data ) {
                            el.html(data)
                        })
                    });
                    $('p[id="server_status"]').each(function () {
                        var el = $(this);
                        var url = "stext.php?ip=" +  el.attr('name') + "&port="+ el.attr('value') +"&full";
                        $.get( url, function( data ) {
                            el.html(data)
                        })
                    });
                }
                $( document ).ready(function() {
                    status();
                    setInterval(status,8000);
                });
            </script>
          
          

          
          
          
        </div>
      </div>

    </main>

    <footer class="text-muted">
      <div class="container">
        <p class="float-right">
          <a href="#">Back to top</a>
        </p>
        <p>Minecraft survival server SMP gith.me</p>
        
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script src="/popper.min.js"></script>
    <script src="/bootstrap.min.js"></script>
    <script src="/holder.min.js"></script>
  
<script type="application/ld+json">
		{
			"@context": "https://schema.org",
			"@type": "WebSite",
			"url": "https://manacube.com/",
			"potentialAction": {
				"@type": "SearchAction",
				"target": "https://manacube.com/search/search?keywords={search_keywords}",
				"query-input": "required name=search_keywords"
			}
		}
		</script>
		
		
<script src="https://cdn.jsdelivr.net/sweetalert2/6.6.0/sweetalert2.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Cookies.js/1.2.1/cookies.min.js" type="text/javascript"></script>
<script type="-text/javascript">

// click to copy
new ClipboardJS('#ndzn-js--copyip', {
	text: () => ip
}).on('success', e => {
	swal(
		'Server IP Copied',
		'We hope to see you online soon!',
		'success'
	)
});

// copy mc ip
new ClipboardJS('#ndzn-js--copyip-mc', {
	text: () => "mc.manacube.com"
}).on('success', e => {
	swal(
		'Server IP Copied',
		'We hope to see you online soon!',
		'success'
	)
});	
	
// copy mc ip
new ClipboardJS('#ndzn-js--copyip-join', {
	text: () => "join.manacube.net"
}).on('success', e => {
	swal(
		'Server IP Copied',
		'We hope to see you online soon!',
		'success'
	)
});	

// server playercount
let ip = 'play.manacube.com';
// $.get('https://mcapi.us/server/status?ip=' + ip, function(res){
// 	if (res.status !== 'success') return null;
// 	$('#ndzn-js--playercount').html(res.players.now);
// });

// discord count
if ($('.ndzn-js--discordcount').length) {
	$.get('https://discordapp.com/api/guilds/224546291663896578/embed.json', function(d){
		$('.ndzn-js--discordcount').html(d['presence_count']);
	});
}

// discord top popup
$(function(){
	if (Cookies.get('ndzn_discord_hidden') != 'yes') {
		$('#ndzn-discord-popup').addClass('visible');
	}
	$('#ndzn-discord-popup .button.muted').click(function(){
		Cookies.set('ndzn_discord_hidden', 'yes', { expires: 60 * 60 * 24 * 30 });
		$('#ndzn-discord-popup').removeClass('visible');
	});
});

// active page
$(function(){
	if (typeof NDZN_ACTIVE_PAGE === 'undefined') {
		$('#ndzn-nav-items .item:nth-of-type(2)').addClass('active');
	} else {
		$('#ndzn-nav-items .item:nth-of-type('+NDZN_ACTIVE_PAGE+')').addClass('active');	
	}
});

// minimize block
$(document).on('click', '.ndzn-js--minimizeBlock', function(e){
	e.preventDefault();
	$(this).closest('.block').toggleClass('minimized');
});

// show mc servers
$('.ndzn-js--showMcServers').click(function(){
	$(this).closest('.group').toggleClass('expanded');
});

$(document).on('click', '.more-dd > a', function(e){
	e.stopImmediatePropagation();
	$(this).closest('.more-dd').toggleClass('more-dd--open');
});

$(document).click(function(){
	$('.more-dd--open').removeClass('more-dd--open');
});
	
	
	
// SERVER STATUS WIDGET

	$(function(){
		let el = '.block[data-widget-key=ndzn_widget__serverstatus]';

		$.get('/api/serverstatus/', function(res){
			if (!res.success) {
				console.error('Could not load server status widget. Removing it :(');
				$(el).remove();
				return null;
			}

			$(el).find('.block-minorHeader small').html(res.server_total);
			$('.ndzn-js--playercount').html(res.server_total);
			$('.ndzn-js--playerTotal').html(res.server_total + ' Players Online');	

			let mc_servers_online_total = 0;

			for (var server_name in res.group_counts) {
				let server_count = res.group_counts[server_name];

				if (server_count === -1) {
					$(el).find('.group--minecraft .group-extra').append(
						'<li class="server offline">' +
						server_name +
						'</li>'
					);
				} else {
					mc_servers_online_total += 1;
					$(el).find('.group--minecraft .group-extra').append(
						'<li class="server online">' +
						server_name +
						'<small>'+server_count+'</small>' +
						'</li>'
					);
				}
			}

			$(el).find('.group--minecraft .group-thumb-text small').html(
				mc_servers_online_total + '/' + Object.keys(res.group_counts).length + ' Servers Online'
			);

			$(el).removeClass('loading');
		});

	});

</script>
  
  
  
<svg xmlns="http://www.w3.org/2000/svg" width="348" height="225" viewBox="0 0 348 225" preserveAspectRatio="none" style="display: none; visibility: hidden; position: absolute; top: -100%; left: -100%;"><defs><style type="text/css"></style></defs><text x="0" y="17" style="font-weight:bold;font-size:17pt;font-family:Arial, Helvetica, Open Sans, sans-serif"></text></svg>




</body>

</html>