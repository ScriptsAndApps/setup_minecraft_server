<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?><!DOCTYPE html>
<html>
<head>
    <title>Example CONCEPT port encoding in ipv4 format to use in dns record for minecraft or other applications</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js?t=<?php echo time(); ?>"></script>
<script>
$(document).ready(function(){
        $("#bport").click(function(){
            var port =  $( "#port" ).val();
            var url = "portipconverter.php?port=" + port;
            $.get( url, function( data ) { $( "#portout" ) .html( data ) } );
        });
        
        $("#bip").click(function(){
            var ip =  $( "#ip" ).val();
            var url = "portipconverter.php?ip=" + ip;
            $.get( url, function( data ) { $( "#ipout" ) .html( data ) } );
        });
        
        $("#bdnstoport").click(function(){
            var varr =  $( "#dnstoport" ).val();
            var url = "portipconverter.php?dnstoport=" + varr;
            $.get( url, function( data ) { $( "#dnstoportout" ) .html( data ) } );
        });
        
        $("#bdnslookup").click(function(){
            var varr =  $( "#dnslookup" ).val();
            var url = "portipconverter.php?dnslookup=" + varr;
            $.get( url, function( data ) { $( "#dnslookupout" ) .html( data ) } );
        });
});
</script>
</head>
<body>
<center><h2>Example CONCEPT port encoding in ipv4 format to use in dns record for minecraft or other applications</h2>

<br />

<lable>Port to convert to Ipv4 format </lable><br>
<input type="text" style="width:300px;text-align:center"  value="25565" id="port"></input><br /><br />
<button id="bport">Convert to ipv4 format ( to put in minecraftport.domain.example )</button>
<p id="portout"></p>

<br />

<lable> </lable>
<input type="text" style="width:300px;text-align:center"  value="249.102.0.167" id="ip"></input><br /><br />
<button id="bip">Convert to port</button>
<p id="ipout"></p>

<br />

Exaplme dns to see what port it gives<br>
<pre>
onetwotreefourfive.gith.me
thedevilsport.gith.me
rcon.gith.me
minecraftport.gith.me 
e6.port.me
</pre>


<lable>DNS to port Lookup</lable><br />

<input type="text"  style="width:300px;text-align:center" value="minecraftport.gith.me" id="dnstoport"></input>
<br /><br />
<button id="bdnstoport">Change content of all p elements</button>
<br />
<lable>This should be implemented in minecraft client</lable><br />

<p id="dnstoportout"></p>

<br />

<lable>DNS lookup</lable><br />
<input type="text" style="width:300px;text-align:center"  value="google.com" id="dnslookup"></input><br /><br />
<button id="bdnslookup">Change content of all p elements</button>
<p id="dnslookupout"></p>


<br>

<br>
</center>
<br>

<br>
<pre>
//Minecraft should use something like this to get the port from  a dns subdomain the user has set
    
//import java.net.InetAddress;

public class HelloWorld {
    public static void main(String[] args) {
        String RawIpv4 = "249.102.0.167";
        
        //String domaintoprt = "minecraftport.gith.me";
        //RawIpv4 = getIpv4FromDomain(domaintoprt);
        //System.out.println( "# Getting port for: "+  domaintoprt + " # "); 
        
        int calculated_port = calculateport( RawIpv4 );
           System.out.println( "# calculated_port " + calculated_port ); 
    }
    
  static  public String getIpv4FromDomain(String domain){
        String Ipv4 = "";
        try {
            //InetAddress address = InetAddress.getByName(domain); 
            //Ipv4 = address.getHostAddress();
        }catch (Exception e){}
        return Ipv4;
    }
    
     public static int calculateport(String ipv4) {
        
        int port = 0;
            
        String [] split = ipv4.split("\\.");
        String temp = ipv4;
        int num1 = Integer.parseInt(split[0]);
        int num2= Integer.parseInt(split[1]);
        int num3= Integer.parseInt(split[2]);
        int num4= Integer.parseInt(split[3]);
        
        int rest = 0;
        int portout = 0; 
         
        if(num3 < 10){
        	if(num3 == 0){		
        			rest = num4;
        	}else{		
        		rest = (num3*100) + num4 + 100;
        	}	
        }else if(num3 < 100){
            String num3s = "" + num3;
        	int fs = Integer.parseInt(num3s.substring(1));

        	String thou = num3s.substring(0,1);
        	int thousendtimes = Integer.parseInt(thou) * 1000;
        	if(fs==0)
        	{
                rest =  num4 ;
        	}else{
                rest = (fs*100) + num4 + 100;
        	}
            rest = rest + thousendtimes;

        }else{
        	//not implemented port above 62001 not used
        	rest = 10000000;
        }
        if(num2!=0){
        	portout = num1 * num2 + rest;
        }else{
             portout = num1 + rest;
        }
        return portout;
    }

}

</pre>
<center>
<h4> Source in php (the math can be used in any coding language like java) </h4>
</center>

<pre>
&lt;?php

function getIpv4FromSubdomain($_domain){
    putenv('RES_OPTIONS=retrans:1 retry:1 timeout:1 attempts:1');
    $ip = gethostbyname($_domain);
    return $ip;
    
}

function generateIpv4($_port){
    
 if((int)$_port > 249)
 {
	if( (int)$_port > 62001)
	{
	    //todo Ports above 62001 not used ?
		$result = "0.0.0.0";
	}else{
		$n = (int)($_port/249); // number times 249
		$y  = 249 * (int)$n; // 25647
		$y =  (int)$_port - (int)$y; // 25665 - rest = 18
		if($y <= 249){
			$result = "249." . $n .".0.". $y;
		 }else{
			if($y<1000){
				if($y > 100){
					$f = ($y - 100)."";   //this 100 needs to be removed to not exceed 249 we add it back later in the reversed conversion
				}else{
					 $f = ($y)."";
				}
				if($f >= 100)
				{
					
					$fl = substr($f,0,1);						
					$b = substr($f,1);
					$b  = (int)$b ;
					$result = "249.".$n .".".$fl ."." . $b;
					
					
				}else{
						$result = "249.".$n .".0" ."." . $f;
				}
			}else{
				
			    // y = 1000+
				$f = ($y - 100)."";   //this 100 needs to be removed to not exceed 249 we add it back later in the reversed conversion
				
				//removes the thousend in front for easy maths
				if(strlen($y)==4){
					$f =  substr($f,1);
					$ln = (int)substr($f,0,1);
				}else{
					$ln = 0;
				}
				
				
				if($f >= 100)
				{
					$fl = substr($f,0,1);						
					$b = substr($f,1);
					$result = "249.".$n .".".$ln.$fl ."." . $b;
				}else{
					$result = "249.".$n .".".$ln ."0." . $f;
				}
			}
		 }
	}
 }
 else
 {
	$result = $_port . ".0.0.0";
 }
return $result;
}





function generatePort($_ipv4){

    $temp = $_ipv4;
    $pos1 = strpos($temp , ".");
    $num1 = substr($temp ,0,$pos1);
    $temp = substr($temp,$pos1+1);
    $pos2 = strpos($temp, ".");
    $num2 = substr($temp,0,$pos2);
    $temp = substr($temp,$pos2+1);
    $pos3 = strpos($temp, ".");
    $num3 = substr($temp,0,$pos3);
    $temp = substr($temp,$pos3+1);
    $num4 = $temp;
    if($num3 < 10){
    	if($num3 == 0){		
    			$rest = (int)$num4;
    	}else{		
    		$rest = ((int)$num3*100) + (int)$num4 + 100; //this 100 comes from the generator it needs to remove a hundred to not exceed 249 and its removed so we add it here
    	}									
    }else if($num3 < 100){
        $num3 = $num3."";
    	$f =  substr($num3,1);
    	$s =  (int)substr($num3,0,1) * 1000;
    	if($s==0){
    	    $r = ($num4);
    	}else{
    	    $r = ((int)$f*100) + $num4 + 100; //this 100 comes from the generator it needs to remove a hundred to not exceed 249 and its removed so we add it here
    	}
    	$rest = $r + $s;
    }else{
    	//not implemented port above 62001 not used
    	$rest = 10000000;
    }
    if($num2!=0){
    	$portout = (int)$num1*(int)$num2 + (int)$rest;
    }else{
        $portout = (int)$num1 + (int)$rest;
    }
  
return $portout;
}



function showPorttoIpv4($_port)
{
    $ipv4 =  generateIpv4($_port);
    $genport = generatePort($ipv4);
    echo "ipv4 encoded: &lt;br>&lt;br>(Put this in minecraftportt&lt;i>.domain.example&lt;/i>)&lt;br> &lt;b>". $ipv4 ;
    echo "&lt;/b>&lt;br> ";
    echo "&lt;br>&lt;s>Given port: ".$_port ." => ". $genport . "\n&lt;br>Status: " .( ($genport == $_port) ? " Correct " :" Failure") ." &lt;/s>";
}

function showIpv4toPort($_ipv4)
{
    $genport = generatePort($_ipv4);

    echo "\n&lt;br>Decoded Port  " . $genport ;
    echo "\n&lt;br>&lt;s>Given ipv4: ".$_ipv4."&lt;/s>";
}  

if(isset($_GET['dnslookup'])){
    echo $_GET['dnslookup']. " = ";
    echo getIpv4FromSubdomain($_GET['dnslookup']);    
    
}
else if(isset($_GET['dnstoport'])){

    $ip  = getIpv4FromSubdomain($_GET['dnstoport']); 
    echo $_GET['dnstoport']." ( &lt;s>".$ip."&lt;/s> )";
    echo "\n<br>Converted Dns to port: ";
    echo  generatePort($ip);    
    
}else if(isset($_GET['port'])){
        showPorttoIpv4((int)$_GET['port']);
}else if(isset($_GET['ip'])){
        showIpv4toPort($_GET['ip']);
}

?>


</pre>
 
 
 
 
 
</body>
</html>
