<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); 


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getIpv4FromSubdomain($_domain){
    putenv('RES_OPTIONS=retrans:1 retry:1 timeout:1 attempts:1');
    $ip = gethostbyname($_domain);
    return $ip;
    
}

function generateIpv4($_port){
    
 if((int)$_port > 249)
 {
	if( (int)$_port > 62001)
	{
	    //todo Ports above 62001 not used ?
		$result = "0.0.0.0";
	}else{
		$n = (int)($_port/249); // number times 249
		$y  = 249 * (int)$n; // 25647
		$y =  (int)$_port - (int)$y; // 25665 - rest = 18
		if($y <= 249){
			$result = "249." . $n .".0.". $y;
		 }else{
			if($y<1000){
				if($y > 100){
					$f = ($y - 100)."";   //this 100 needs to be removed to not exceed 249 we add it back later in the reversed conversion
				}else{
					 $f = ($y)."";
				}
				if($f >= 100)
				{
					
					$fl = substr($f,0,1);						
					$b = substr($f,1);
					$b  = (int)$b ;
					$result = "249.".$n .".".$fl ."." . $b;
					
					
				}else{
						$result = "249.".$n .".0" ."." . $f;
				}
			}else{
				
			    // y = 1000+
				$f = ($y - 100)."";   //this 100 needs to be removed to not exceed 249 we add it back later in the reversed conversion
				
				//removes the thousend in front for easy maths
				if(strlen($y)==4){
					$f =  substr($f,1);
					$ln = (int)substr($f,0,1);
				}else{
					$ln = 0;
				}
				
				
				if($f >= 100)
				{
					$fl = substr($f,0,1);						
					$b = substr($f,1);
					$result = "249.".$n .".".$ln.$fl ."." . $b;
				}else{
					$result = "249.".$n .".".$ln ."0." . $f;
				}
			}
		 }
	}
 }
 else
 {
	$result = $_port . ".0.0.0";
 }
return $result;
}



function generatePort($_ipv4){

    $temp = $_ipv4;
    $pos1 = strpos($temp , ".");
    $num1 = substr($temp ,0,$pos1);
    $temp = substr($temp,$pos1+1);
    $pos2 = strpos($temp, ".");
    $num2 = substr($temp,0,$pos2);
    $temp = substr($temp,$pos2+1);
    $pos3 = strpos($temp, ".");
    $num3 = substr($temp,0,$pos3);
    $temp = substr($temp,$pos3+1);
    $num4 = $temp;
    if($num3 < 10){
    	if($num3 == 0){		
    			$rest = (int)$num4;
    	}else{		
    		$rest = ((int)$num3*100) + (int)$num4 + 100; //this 100 comes from the generator it needs to remove a hundred to not exceed 249 and its removed so we add it here
    	}									
    }else if($num3 < 100){
        $num3 = $num3."";
    	$f =  substr($num3,1);
    	$s =  (int)substr($num3,0,1) * 1000;
    	if($s==0){
    	    $r = ($num4);
    	}else{
    	    $r = ((int)$f*100) + $num4 + 100; //this 100 comes from the generator it needs to remove a hundred to not exceed 249 and its removed so we add it here
    	}
    	$rest = $r + $s;
    }else{
    	//not implemented port above 62001 not used
    	$rest = 1000000;
    }
    if($num2!=0){
    	$portout = (int)$num1*(int)$num2 + (int)$rest;
    }else{
        $portout = (int)$num1 + (int)$rest;
    }
  
return $portout;
}



function showPorttoIpv4($_port)
{
    $ipv4 =  generateIpv4($_port);
    $genport = generatePort($ipv4);
    echo "ipv4 encoded: <br><br>(Put this in minecraftportt<i>.domain.example</i>)<br> <b>". $ipv4 ;
    echo "</b><br> ";
    echo "<br><s>Given port: ".$_port ." => ". $genport . "\n<br>Status: " .( ($genport == $_port) ? " Correct " :" Failure") ." </s>";
}

function showIpv4toPort($_ipv4)
{
    $genport = generatePort($_ipv4);

    echo "\n<br>Decoded Port  " . $genport ;
    echo "\n<br><s>Given ipv4: ".$_ipv4."</s>";
}  

if(isset($_GET['dnslookup'])){
    echo $_GET['dnslookup']. " = ";
    echo getIpv4FromSubdomain($_GET['dnslookup']);    
    
}
else if(isset($_GET['dnstoport'])){

    $ip  = getIpv4FromSubdomain($_GET['dnstoport']); 
    echo $_GET['dnstoport']." ( <s>".$ip."</s> )";
    echo "\n<br>Converted Dns to port: ";
    echo  generatePort($ip);    
    
}else if(isset($_GET['port'])){
        showPorttoIpv4((int)$_GET['port']);
}else if(isset($_GET['ip'])){
        showIpv4toPort($_GET['ip']);
}




